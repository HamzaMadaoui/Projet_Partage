import { test as base, type Page } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashboardPage';

/**
 * Extended test fixture that provides an already-authenticated session.
 *
 * The "chromium" project loads storageState automatically via playwright.config.ts.
 * This fixture simply navigates to the dashboard — no login round-trip needed.
 *
 * Usage: import { test } from '../fixtures/auth.fixture'
 */
type AuthFixtures = {
  authenticatedPage: Page;
  loginPage: LoginPage;
  dashboardPage: DashboardPage;
};

export const test = base.extend<AuthFixtures>({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },

  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page));
  },

  authenticatedPage: async ({ page }, use) => {
    // storageState already loaded by playwright.config.ts — just navigate
    await page.goto('/#/');
    await page.waitForURL(/cloud\.consigno\.com\/#/, { timeout: 20_000 });
    await use(page);
  },
});

export { expect } from '@playwright/test';
