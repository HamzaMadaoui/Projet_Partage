import { test, expect } from '../fixtures/auth.fixture';
import { UserAccountPage } from '../pages/UserAccountPage';
import { USERS } from '../utils/test-data';

/**
 * User Account Tests
 *
 * Business rationale: In a legal e-signature platform, user identity data
 * is critical. First name, last name and email feed directly into the
 * legally-recognised signature metadata. 2FA protects against unauthorized
 * signature issuance - a potentially catastrophic security failure.
 *
 * Coverage:
 * - Profile data integrity (pre-populated from server)
 * - Security section presence (password change, 2FA)
 * - 2FA method options (SMS, phone call)
 * - Phone number field and country code
 * - Navigation back to dashboard
 */

test.describe('User Account', () => {
  let accountPage: UserAccountPage;

  test.beforeEach(async ({ authenticatedPage }) => {
    accountPage = new UserAccountPage(authenticatedPage);
    await accountPage.goto();
    await accountPage.assertPageLoaded();
  });

  test.describe('Page integrity', () => {
    test('should display "Mon compte" heading', async () => {
      await expect(accountPage.heading).toBeVisible();
    });

    test('should display first name field pre-populated', async () => {
      await expect(accountPage.firstNameInput).toHaveValue(USERS.valid.firstName);
    });

    test('should display last name field pre-populated', async () => {
      await expect(accountPage.lastNameInput).toHaveValue(USERS.valid.lastName);
    });

    test('should display email field pre-populated with registered email', async () => {
      await expect(accountPage.emailInput).toHaveValue(USERS.valid.email);
    });

    test('should display all profile data correctly in one assertion', async () => {
      await accountPage.assertProfileData(
        USERS.valid.firstName,
        USERS.valid.lastName,
        USERS.valid.email,
      );
    });
  });

  test.describe('Security settings', () => {
    test('should display "Changer le mot de passe" section', async () => {
      await expect(accountPage.changePasswordSection).toBeVisible();
    });

    test('should display 2FA configuration section', async ({ authenticatedPage }) => {
      await expect(
        authenticatedPage.getByText(/second facteur d'authentification/i),
      ).toBeVisible();
    });

    test('should offer SMS as a 2FA method option', async ({ authenticatedPage }) => {
      await expect(authenticatedPage.getByRole('listitem').filter({ hasText: 'SMS' })).toBeVisible();
    });

    test('should offer phone call as a 2FA method option', async ({ authenticatedPage }) => {
      await expect(
        authenticatedPage.getByRole('listitem').filter({ hasText: /appel téléphonique/i }),
      ).toBeVisible();
    });

    test('should display phone number input with existing number', async () => {
      await expect(accountPage.phoneNumberInput).toBeVisible();
      // The phone field should not be empty for a configured account
      const value = await accountPage.phoneNumberInput.inputValue();
      expect(value.length).toBeGreaterThan(0);
    });

    test('should display country code selector', async () => {
      await expect(accountPage.countryCodeButton).toBeVisible();
    });

    test('country code should default to Canada (+1)', async () => {
      const label = await accountPage.countryCodeButton.getAttribute('aria-label') ?? '';
      expect(label.toLowerCase()).toContain('canada');
    });
  });

  test.describe('Navigation', () => {
    test('should display "Retour" link', async () => {
      await expect(accountPage.backLink).toBeVisible();
    });

    test('should navigate back to dashboard via Retour link', async ({ authenticatedPage }) => {
      await accountPage.backLink.click();
      // "Retour" redirects to /#/ which renders the dashboard
      await expect(authenticatedPage).toHaveURL(/cloud\.consigno\.com\/#/);
      await expect(authenticatedPage.getByRole('button', { name: /nouveau projet/i })).toBeVisible();
    });
  });

  test.describe('Access guard', () => {
    test('page URL should be /#/user-account', async ({ authenticatedPage }) => {
      await expect(authenticatedPage).toHaveURL(/\/#\/user-account/);
    });
  });
});
