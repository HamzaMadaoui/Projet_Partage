import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { USERS, URLS } from '../utils/test-data';

/**
 * Authentication Tests
 *
 * Business rationale: The login screen is the security gate of a
 * legally-binding e-signature platform. Any authentication failure
 * has direct legal and compliance consequences.
 *
 * Coverage:
 * - Happy path: valid credentials → dashboard redirect
 * - Negative: wrong password, wrong email, malformed email, empty fields
 * - UX: forgot password navigation, language switch, terms link
 * - Security: password field masking, no credential leakage in URL
 */

test.describe('Authentication', () => {
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.goto();
  });

  test.describe('Page integrity', () => {
    test('should display the login form with all required elements', async ({ page }) => {
      await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
      await expect(loginPage.emailInput).toBeVisible();
      await expect(loginPage.passwordInput).toBeVisible();
      await expect(loginPage.submitButton).toBeVisible();
      await expect(loginPage.forgotPasswordLink).toBeVisible();
    });

    test('should display ConsignO Cloud logo linking to home', async () => {
      await expect(loginPage.logoLink).toBeVisible();
    });

    test('should display Terms of Use link in footer', async () => {
      await expect(loginPage.termsLink).toBeVisible();
    });

    test('should display copyright notice in footer', async () => {
      await expect(loginPage.copyrightNotice).toBeVisible();
    });

    test('password field should mask input for security', async ({ page }) => {
      // input[type="password"] has no ARIA textbox role - target by CSS selector
      const passwordType = await page
        .locator('input[type="password"]')
        .getAttribute('type');
      // Password inputs must use type="password" to mask characters
      expect(passwordType).toBe('password');
    });

    test('should not expose credentials in the URL after submit attempt', async ({ page }) => {
      await loginPage.login(USERS.valid.email, USERS.valid.password);
      await page.waitForTimeout(2000);
      const url = page.url();
      expect(url).not.toContain(USERS.valid.email);
      expect(url).not.toContain(USERS.valid.password);
    });
  });

  test.describe('Successful login', () => {
    test('should redirect to dashboard after valid login', async ({ page }) => {
      await loginPage.loginAndWaitForDashboard(USERS.valid.email, USERS.valid.password);
      await expect(page).toHaveURL(/\/#\/dashboard/);
    });

    test('should display user full name in header after login', async ({ page }) => {
      await loginPage.loginAndWaitForDashboard(USERS.valid.email, USERS.valid.password);
      await expect(page.getByText(USERS.valid.fullName)).toBeVisible();
    });

    test('should show "Nouveau projet" action button after login', async ({ page }) => {
      await loginPage.loginAndWaitForDashboard(USERS.valid.email, USERS.valid.password);
      await expect(page.getByRole('button', { name: /nouveau projet/i })).toBeVisible();
    });
  });

  test.describe('Failed login scenarios', () => {
    test('should remain on login page with wrong password', async ({ page }) => {
      await loginPage.login(USERS.invalidPassword.email, USERS.invalidPassword.password);
      await page.waitForTimeout(3000);
      await loginPage.assertOnLoginPage();
    });

    test('should show error message with wrong password', async ({ page }) => {
      await loginPage.login(USERS.invalidPassword.email, USERS.invalidPassword.password);
      // App renders error text in a <p> or similar element (not role="alert")
      // Wait for any visible error-like text after failed login
      // #errorDiv is the unique element for auth errors (class="alert alert-danger")
      await expect(page.locator('#errorDiv')).toBeVisible({ timeout: 12_000 });
    });

    test('should remain on login page with unknown email', async ({ page }) => {
      await loginPage.login(USERS.invalidEmail.email, USERS.invalidEmail.password);
      await page.waitForTimeout(3000);
      await loginPage.assertOnLoginPage();
    });

    test('should block submission with empty email', async ({ page }) => {
      await loginPage.passwordInput.fill(USERS.valid.password);
      await loginPage.submitButton.click();
      await page.waitForTimeout(1000);
      // Must stay on login page - form validation or server rejection
      await expect(page).toHaveURL(/\/login/);
    });

    test('should block submission with empty password', async ({ page }) => {
      await loginPage.emailInput.fill(USERS.valid.email);
      await loginPage.submitButton.click();
      await page.waitForTimeout(1000);
      await expect(page).toHaveURL(/\/login/);
    });

    test('should block submission with both fields empty', async ({ page }) => {
      await loginPage.submitButton.click();
      await page.waitForTimeout(1000);
      await expect(page).toHaveURL(/\/login/);
    });
  });

  test.describe('Navigation and UX', () => {
    test('should navigate to forgot password page', async ({ page }) => {
      await loginPage.forgotPasswordLink.click();
      await expect(page).toHaveURL(/forgot-password/);
    });

    test('should display language switcher', async ({ page }) => {
      // The platform is bilingual - FR and EN must be switchable
      const languageOptions = page.getByRole('listitem');
      await expect(languageOptions.filter({ hasText: 'English' })).toBeVisible();
      await expect(languageOptions.filter({ hasText: 'Français' })).toBeVisible();
    });

    test('should switch to English and update heading', async ({ page }) => {
      // The login page language switcher uses a Bootstrap dropdown with listitem options.
      // The items may be hidden until the dropdown is opened; force: true bypasses visibility check.
      const englishOption = page.getByRole('listitem').filter({ hasText: 'English' });
      await englishOption.click({ force: true });
      await page.waitForTimeout(800);
      // After language switch the heading changes to "Sign in"
      await expect(page.getByRole('heading', { level: 1 })).toContainText(/sign in/i);
    });
  });
});
