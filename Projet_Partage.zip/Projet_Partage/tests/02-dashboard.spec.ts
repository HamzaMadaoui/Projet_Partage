import { test, expect } from '../fixtures/auth.fixture';
import { DashboardPage } from '../pages/DashboardPage';
import { PROJECT_STATUSES, NAV_SECTIONS } from '../utils/test-data';

/**
 * Dashboard Tests
 *
 * Business rationale: The dashboard is the user's mission control.
 * Project filtering and search directly impact operational efficiency -
 * a notary or legal professional who can't find a project quickly
 * loses billable time and may miss signing deadlines.
 *
 * Coverage:
 * - Navigation sidebar completeness
 * - Project status filter (all 7 statuses)
 * - Search functionality
 * - User menu completeness
 * - Section heading accuracy
 * - Logout flow
 */

test.describe('Dashboard', () => {
  let dashboard: DashboardPage;

  test.beforeEach(async ({ authenticatedPage }) => {
    dashboard = new DashboardPage(authenticatedPage);
    await dashboard.assertOnDashboard();
  });

  test.describe('Layout and navigation', () => {
    test('should display all sidebar navigation sections', async ({ authenticatedPage }) => {
      for (const section of Object.values(NAV_SECTIONS)) {
        await expect(authenticatedPage.getByTitle(section)).toBeVisible();
      }
    });

    test('should display "Nouveau projet" button prominently', async () => {
      await expect(dashboard.newProjectButton).toBeVisible();
    });

    test('should display search input with placeholder', async () => {
      await expect(dashboard.searchInput).toBeVisible();
    });

    test('should display refresh button for project list', async () => {
      await expect(dashboard.refreshButton).toBeVisible();
    });

    test('should show "Mes projets" as default active section heading', async () => {
      const heading = await dashboard.getCurrentSectionHeading();
      expect(heading).toMatch(/mes projets/i);
    });

    test('should display authenticated user name in header', async ({ authenticatedPage }) => {
      await expect(authenticatedPage.getByText('HAMZA MADAOUI')).toBeVisible();
    });
  });

  test.describe('User menu', () => {
    test('should show all user menu options on click', async ({ authenticatedPage }) => {
      await dashboard.openUserMenu();
      await expect(authenticatedPage.getByText('Préférences')).toBeVisible();
      await expect(authenticatedPage.getByText('Mon compte')).toBeVisible();
      await expect(authenticatedPage.getByText('Mon organisation')).toBeVisible();
      await expect(authenticatedPage.getByText("Carnet d'adresses")).toBeVisible();
      await expect(authenticatedPage.getByText('Me déconnecter')).toBeVisible();
    });

    test('should navigate to "Mon compte" from user menu', async ({ authenticatedPage }) => {
      await dashboard.openUserMenu();
      await authenticatedPage.getByText('Mon compte').click();
      await expect(authenticatedPage).toHaveURL(/\/#\/user-account/);
    });
  });

  test.describe('Project status filter', () => {
    for (const status of PROJECT_STATUSES) {
      test(`should allow filtering by status: "${status}"`, async ({ authenticatedPage }) => {
        // The filter is a nice-select dropdown with class .workflow-filter
        const dropdown = authenticatedPage.locator('.nice-select.workflow-filter');
        await dropdown.click();
        // Click the option inside the dropdown list
        const option = dropdown.locator('.list li').filter({ hasText: status });
        await expect(option).toBeVisible();
        await option.click();
        // After selecting, the page should still be functional
        await authenticatedPage.waitForTimeout(500);
        await expect(dashboard.newProjectButton).toBeVisible();
      });
    }
  });

  test.describe('Search functionality', () => {
    test('should accept text input in search field', async () => {
      await dashboard.searchInput.fill('test project');
      await expect(dashboard.searchInput).toHaveValue('test project');
    });

    test('should clear search field', async () => {
      await dashboard.searchInput.fill('some query');
      await dashboard.searchInput.clear();
      await expect(dashboard.searchInput).toHaveValue('');
    });

    test('should not crash when searching with special characters', async ({ authenticatedPage }) => {
      await dashboard.searchInput.fill("O'Brien & Associates <test>");
      await authenticatedPage.waitForTimeout(600);
      // Page must remain functional - no unhandled errors
      await expect(dashboard.newProjectButton).toBeVisible();
    });

    test('should not crash when searching with an empty string after a query', async ({ authenticatedPage }) => {
      await dashboard.searchInput.fill('something');
      await authenticatedPage.waitForTimeout(300);
      await dashboard.searchInput.clear();
      await authenticatedPage.waitForTimeout(600);
      await expect(dashboard.newProjectButton).toBeVisible();
    });
  });

  test.describe('Section navigation', () => {
    test('should navigate to Templates section', async ({ authenticatedPage }) => {
      await dashboard.templatesNav.click();
      await expect(authenticatedPage.getByRole('heading', { name: /modèles/i })).toBeVisible();
    });

    test('should display upgrade banner in Org Users section (free trial)', async ({ authenticatedPage }) => {
      await dashboard.orgUsersNav.click();
      await expect(
        authenticatedPage.getByText(/passez au forfait/i),
      ).toBeVisible();
    });

    test('should navigate back to My Projects from another section', async ({ authenticatedPage }) => {
      await dashboard.templatesNav.click();
      await dashboard.myProjectsNav.click();
      const heading = await dashboard.getCurrentSectionHeading();
      expect(heading).toMatch(/mes projets/i);
    });
  });

});
