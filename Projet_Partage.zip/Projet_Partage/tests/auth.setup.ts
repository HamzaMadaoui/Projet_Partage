import { test as setup } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { USERS } from '../utils/test-data';

const authFile = 'playwright/.auth/user.json';

/**
 * Auth setup: runs once before authenticated tests.
 * Logs in and saves the browser session to disk.
 * The "chromium" project loads this session via storageState.
 */
setup('authenticate', async ({ page }) => {
  const loginPage = new LoginPage(page);
  await loginPage.goto();
  await loginPage.loginAndWaitForDashboard(USERS.valid.email, USERS.valid.password);
  await page.context().storageState({ path: authFile });
});
