import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashboardPage';
import { USERS } from '../utils/test-data';

/**
 * Logout Tests
 *
 * Isolated project that runs LAST (defined after chromium in playwright.config.ts).
 * Each test does a fresh login so the shared storageState session is never invalidated,
 * preventing cascading failures on all other authenticated tests.
 */
test.describe('Logout', () => {
  let dashboard: DashboardPage;

  test.beforeEach(async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.loginAndWaitForDashboard(USERS.valid.email, USERS.valid.password);
    dashboard = new DashboardPage(page);
  });

  test('should log out and redirect to login page', async ({ page }) => {
    await dashboard.logout();
    await expect(page).toHaveURL(/\/login/);
  });

  test('should not be able to access dashboard after logout', async ({ page }) => {
    await dashboard.logout();
    await page.goto('https://cloud.consigno.com/#/dashboard');
    await page.waitForLoadState('networkidle');
    // Should redirect back to login - unauthenticated access must be blocked
    await expect(page).toHaveURL(/\/login/);
  });
});
