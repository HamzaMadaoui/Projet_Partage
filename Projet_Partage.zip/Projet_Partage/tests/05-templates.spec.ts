import { test, expect } from '../fixtures/auth.fixture';
import { TemplatesPage } from '../pages/TemplatesPage';
import { DashboardPage } from '../pages/DashboardPage';

/**
 * Templates Tests
 *
 * Business rationale: Templates allow legal professionals to standardize
 * signing workflows (e.g., mortgage documents, shareholder agreements).
 * A broken template system forces users to re-configure projects from
 * scratch on every use - wasting time and introducing human error.
 *
 * Coverage:
 * - Templates section loads correctly
 * - Table structure is correct (sortable columns)
 * - Empty state message is user-friendly
 * - Search field is present
 * - Create new template CTA is accessible
 */

test.describe('Templates', () => {
  let templatesPage: TemplatesPage;
  let dashboard: DashboardPage;

  test.beforeEach(async ({ authenticatedPage }) => {
    dashboard = new DashboardPage(authenticatedPage);
    templatesPage = new TemplatesPage(authenticatedPage);
    await dashboard.goto();
    await dashboard.navigateToTemplates();
  });

  test.describe('Page structure', () => {
    test('should display "Modèles" heading', async () => {
      await expect(templatesPage.heading).toBeVisible();
    });

    test('should display "Nouveau modèle" action link', async () => {
      await expect(templatesPage.newTemplateLink).toBeVisible();
    });

    test('should display search input', async () => {
      await expect(templatesPage.searchInput).toBeVisible();
    });

    test('should display template table', async () => {
      await expect(templatesPage.templateTable).toBeVisible();
    });
  });

  test.describe('Table columns', () => {
    test('should have all required columns', async () => {
      await templatesPage.assertTableColumnsPresent();
    });

    test('should have "Nom" column', async () => {
      await expect(templatesPage.nameColumn).toBeVisible();
    });

    test('should have "Dernière modification" column', async () => {
      await expect(templatesPage.lastModifiedColumn).toBeVisible();
    });

    test('should have "Modifié par" column', async () => {
      await expect(templatesPage.modifiedByColumn).toBeVisible();
    });

    test('should have "Actions" column', async () => {
      await expect(templatesPage.actionsColumn).toBeVisible();
    });
  });

  test.describe('Empty state', () => {
    test('should display "Aucun modèle" message when list is empty', async () => {
      await expect(templatesPage.emptyStateMessage).toBeVisible();
    });
  });

  test.describe('Search', () => {
    test('should accept text in search field', async ({ authenticatedPage }) => {
      await templatesPage.searchInput.fill('Contrat');
      await expect(templatesPage.searchInput).toHaveValue('Contrat');
    });

    test('should not crash on search with no results', async ({ authenticatedPage }) => {
      await templatesPage.searchInput.fill('xxxxxxxxxxxxxxxxxxx');
      await authenticatedPage.waitForTimeout(500);
      // Page remains functional
      await expect(templatesPage.newTemplateLink).toBeVisible();
    });
  });

  test.describe('Navigation to create template', () => {
    test('"Nouveau modèle" link should be clickable', async ({ authenticatedPage }) => {
      await expect(templatesPage.newTemplateLink).toBeEnabled();
    });
  });
});
