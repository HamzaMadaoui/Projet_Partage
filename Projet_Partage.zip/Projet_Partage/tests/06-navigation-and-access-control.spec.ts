import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { USERS } from '../utils/test-data';

/**
 * Navigation & Access Control Tests
 *
 * Business rationale: An e-signature platform handles legally-sensitive
 * documents. Unauthenticated users must never access project data.
 * This test file validates the security boundary between public and
 * protected routes - a compliance requirement.
 *
 * Coverage:
 * - Protected routes redirect unauthenticated users to login
 * - Authenticated users cannot be redirected back to login by accident
 * - Page title reflects the current section (SEO + user orientation)
 * - Back-navigation consistency
 */

const PROTECTED_ROUTES = [
  { path: '/#/dashboard', name: 'Dashboard' },
  { path: '/#/user-account', name: 'User Account' },
  { path: '/#/workflow/create', name: 'Create Project' },
] as const;

test.describe('Navigation & Access Control', () => {
  test.describe('Unauthenticated access', () => {
    for (const route of PROTECTED_ROUTES) {
      test(`should redirect unauthenticated user away from ${route.name}`, async ({ page }) => {
        await page.goto(route.path);
        await page.waitForLoadState('networkidle');
        // Must land on login - protected content must not be exposed
        await expect(page).toHaveURL(/\/login/);
      });
    }

    test('should not display authenticated user content on login page', async ({ page }) => {
      await page.goto('/login');
      await expect(page.getByText('HAMZA MADAOUI')).not.toBeVisible();
      await expect(page.getByRole('button', { name: /nouveau projet/i })).not.toBeVisible();
    });
  });

  test.describe('Page titles', () => {
    test('login page should have correct title', async ({ page }) => {
      await page.goto('/login');
      await expect(page).toHaveTitle(/ConsignO Cloud/i);
    });

    test('dashboard should have correct title after login', async ({ page }) => {
      const loginPage = new LoginPage(page);
      await loginPage.goto();
      await loginPage.loginAndWaitForDashboard(USERS.valid.email, USERS.valid.password);
      await expect(page).toHaveTitle(/ConsignO Cloud/i);
    });

    test('user account should have correct title', async ({ page }) => {
      const loginPage = new LoginPage(page);
      await loginPage.goto();
      await loginPage.loginAndWaitForDashboard(USERS.valid.email, USERS.valid.password);
      await page.goto('/#/user-account');
      await page.waitForLoadState('networkidle');
      await expect(page).toHaveTitle(/User account.*ConsignO Cloud/i);
    });

    test('create project page should have correct title', async ({ page }) => {
      const loginPage = new LoginPage(page);
      await loginPage.goto();
      await loginPage.loginAndWaitForDashboard(USERS.valid.email, USERS.valid.password);
      await page.goto('/#/workflow/create');
      await page.waitForLoadState('networkidle');
      await expect(page).toHaveTitle(/Create new project.*ConsignO Cloud/i);
    });
  });

  test.describe('Forgot password flow', () => {
    test('should navigate to forgot password route from login page', async ({ page }) => {
      await page.goto('/login');
      await page.waitForLoadState('networkidle');
      // The link href is /#/forgot-password - click and verify URL changes
      const link = page.getByRole('link', { name: /mot de passe oublié|forgot/i });
      await expect(link).toBeVisible();
      const href = await link.getAttribute('href');
      // Verify the link points to the forgot-password route
      expect(href).toMatch(/forgot-password/);
    });
  });
});
