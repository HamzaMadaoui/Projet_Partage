import { test, expect } from '../fixtures/auth.fixture';
import { ProjectCreatePage } from '../pages/ProjectCreatePage';
import { DashboardPage } from '../pages/DashboardPage';

/**
 * Project Creation Tests
 *
 * Business rationale: Creating a signing project is the core business
 * transaction on this platform. Any regression here directly prevents
 * customers from executing legally-binding signature workflows.
 *
 * Key business rules tested:
 * - Projects must have a name (identification requirement)
 * - Expiration dates enforce legal deadlines on signatories
 * - Zone counter starts at 0 (no phantom signature zones)
 * - Cancellation must not create orphaned projects
 * - File upload is the central action (no document = no signing)
 * - Signatories and text fields can be added to the workflow
 */

test.describe('Project Creation', () => {
  let projectPage: ProjectCreatePage;
  let dashboard: DashboardPage;

  test.beforeEach(async ({ authenticatedPage }) => {
    projectPage = new ProjectCreatePage(authenticatedPage);
    dashboard = new DashboardPage(authenticatedPage);
    await projectPage.goto();
    await projectPage.assertPageLoaded();
  });

  test.describe('Form initialization', () => {
    test('should display page heading "Créer un projet de signature"', async ({ authenticatedPage }) => {
      await expect(
        authenticatedPage.getByRole('heading', { name: /créer un projet de signature/i }),
      ).toBeVisible();
    });

    test('should display empty project name input', async () => {
      await expect(projectPage.projectNameInput).toBeVisible();
      await expect(projectPage.projectNameInput).toHaveValue('');
    });

    test('should pre-fill expiration date with a default 30-day value', async () => {
      // Business rule: default expiration = today + 30 days
      await projectPage.assertDefaultExpirationDateIsSet();
    });

    test('should show zone counter starting at 0', async () => {
      const count = await projectPage.getZoneCount();
      expect(count).toBe(0);
    });

    test('should display file upload drop zone', async () => {
      await expect(projectPage.fileUploadArea).toBeVisible();
    });

    test('should display "sélectionner les fichiers" button', async () => {
      await expect(projectPage.selectFilesButton).toBeVisible();
    });
  });

  test.describe('Toolbar controls', () => {
    test('should display "Signataires" button', async () => {
      await expect(projectPage.addSignatoryButton).toBeVisible();
    });

    test('should display "Champ de texte" button', async () => {
      await expect(projectPage.addTextFieldButton).toBeVisible();
    });

    test('should display "Options" button', async () => {
      await expect(projectPage.optionsButton).toBeVisible();
    });
  });

  test.describe('Action buttons', () => {
    test('should display Cancel, Save and Launch buttons', async () => {
      await expect(projectPage.cancelButton).toBeVisible();
      await expect(projectPage.saveButton).toBeVisible();
      await expect(projectPage.launchButton).toBeVisible();
    });

    test('should navigate back to dashboard on Cancel', async ({ authenticatedPage }) => {
      await projectPage.cancel();
      // Cancel redirects to /#/ which renders the dashboard (Mes projets)
      await expect(authenticatedPage).toHaveURL(/cloud\.consigno\.com\/#/);
      await expect(dashboard.newProjectButton).toBeVisible();
    });

    test('should keep project name when navigating cancel', async ({ authenticatedPage }) => {
      // Regression: ensure Cancel does not accidentally save a blank draft
      await projectPage.fillProjectName('');
      await projectPage.cancel();
      await expect(authenticatedPage).toHaveURL(/cloud\.consigno\.com\/#/);
    });
  });

  test.describe('Project name input', () => {
    test('should accept alphanumeric project name', async () => {
      await projectPage.fillProjectName('Contrat Vente 2026');
      await expect(projectPage.projectNameInput).toHaveValue('Contrat Vente 2026');
    });

    test('should accept special characters in project name', async () => {
      // Legal project names often include apostrophes, dashes and accents
      const name = "Acte d'hypothèque - Propriété #42";
      await projectPage.fillProjectName(name);
      await expect(projectPage.projectNameInput).toHaveValue(name);
    });

    test('should accept a very long project name', async () => {
      const longName = 'A'.repeat(200);
      await projectPage.fillProjectName(longName);
      // Input should accept the value - truncation if any should be graceful
      const value = await projectPage.projectNameInput.inputValue();
      expect(value.length).toBeGreaterThan(0);
    });
  });

  test.describe('Message to signatories', () => {
    test('should display "Ajouter un message" button', async () => {
      await expect(projectPage.addMessageButton).toBeVisible();
    });

    test('should reveal rich text editor toolbar on click', async ({ authenticatedPage }) => {
      await projectPage.addMessageButton.click();
      // After clicking, the medium-editor toolbar (Bold/Italic buttons) becomes visible
      await expect(
        authenticatedPage.locator('.medium-editor-action-bold'),
      ).toBeVisible();
    });
  });

  test.describe('Expiration date', () => {
    test('should accept a valid future date', async () => {
      await projectPage.setExpirationDate('31/12/2026');
      await expect(projectPage.expirationDateInput).toHaveValue('31/12/2026');
    });
  });

  test.describe('Access control', () => {
    test('should be accessible directly via URL when authenticated', async ({ authenticatedPage }) => {
      await authenticatedPage.goto('/#/workflow/create');
      await authenticatedPage.waitForLoadState('networkidle');
      await expect(authenticatedPage).toHaveURL(/\/#\/workflow\/create/);
    });
  });
});
