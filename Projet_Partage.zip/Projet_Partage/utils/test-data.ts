/**
 * Centralized test data - single source of truth.
 * Never hardcode credentials or test values directly in tests.
 */
export const USERS = {
  valid: {
    email: process.env.TEST_EMAIL!,
    password: process.env.TEST_PASSWORD!,
    firstName: 'HAMZA',
    lastName: 'MADAOUI',
    fullName: 'HAMZA MADAOUI',
  },
  invalidPassword: {
    email: 'hmadaoui@outlook.com',
    password: 'WrongPassword123!',
  },
  invalidEmail: {
    email: 'nonexistent@nowhere.com',
    password: 'AnyPassword123!',
  },
  malformedEmail: {
    email: 'not-an-email',
    password: 'AnyPassword123!',
  },
} as const;

export const URLS = {
  login: '/login',
  dashboard: '/#/dashboard',
  userAccount: '/#/user-account',
  forgotPassword: '/#/forgot-password',
  createProject: '/#/workflow/create',
} as const;

export const PROJECT_STATUSES = [
  'Tous',
  'Brouillon',
  'En cours',
  'Terminé',
  'Expiré',
  'Refusé',
  'À signer',
] as const;

export type ProjectStatus = (typeof PROJECT_STATUSES)[number];

export const NAV_SECTIONS = {
  myProjects: 'Mes projets',
  orgProjects: "Projets de l'organisation",
  orgUsers: "Utilisateurs de l'organisation",
  templates: 'Modèles',
  sharedDocs: 'Mes documents partagés',
  trash: 'Corbeille',
} as const;
