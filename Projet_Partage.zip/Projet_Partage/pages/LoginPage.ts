import { type Page, type Locator, expect } from '@playwright/test';

/**
 * LoginPage - Page Object for the authentication screen.
 *
 * Business context: Entry point for all users of the ConsignO Cloud
 * e-signature platform. Must be reliable, accessible and bilingual (FR/EN).
 */
export class LoginPage {
  readonly page: Page;

  // Form fields
  readonly emailInput: Locator;
  readonly passwordInput: Locator;
  readonly submitButton: Locator;

  // Navigation links
  readonly forgotPasswordLink: Locator;
  readonly logoLink: Locator;

  // Language switcher
  readonly languageSwitcher: Locator;

  // Footer
  readonly termsLink: Locator;
  readonly copyrightNotice: Locator;

  constructor(page: Page) {
    this.page = page;
    this.emailInput = page.getByRole('textbox', { name: /courriel|email/i });
    // input[type="password"] has no ARIA role "textbox" - use CSS selector
    this.passwordInput = page.locator('input[type="password"]');
    this.submitButton = page.getByRole('button', { name: /connecter|sign in/i });
    this.forgotPasswordLink = page.getByRole('link', { name: /mot de passe oublié|forgot/i });
    this.logoLink = page.getByRole('link', { name: 'ConsignO Cloud' });
    // Language switcher uses nice-select library with class .header__lang
    this.languageSwitcher = page.locator('.nice-select.header__lang');
    this.termsLink = page.getByRole('link', { name: /conditions d'utilisation|terms/i });
    this.copyrightNotice = page.getByText(/notarius/i).last();
  }

  async goto(): Promise<void> {
    await this.page.goto('/login');
    await this.page.waitForLoadState('networkidle');
  }

  async login(email: string, password: string): Promise<void> {
    await this.emailInput.fill(email);
    await this.passwordInput.fill(password);
    await this.submitButton.click();
  }

  async loginAndWaitForDashboard(email: string, password: string): Promise<void> {
    await this.login(email, password);
    // App redirects to /#/ or /#/dashboard after successful login
    await this.page.waitForURL(/cloud\.consigno\.com\/#/, { timeout: 30_000 });
  }

  async getPageHeading(): Promise<string> {
    const heading = this.page.getByRole('heading', { level: 1 });
    return (await heading.textContent()) ?? '';
  }

  async isErrorDisplayed(): Promise<boolean> {
    // After a failed login the app renders error text in a <p> or alert element
    const errorText = this.page.locator('p, .alert, .error, [class*="error"], [class*="alert"]').filter({
      hasText: /courriel|mot de passe|erron|invalid|incorrect|wrong/i,
    });
    return errorText.isVisible().catch(() => false);
  }

  async assertOnLoginPage(): Promise<void> {
    await expect(this.page).toHaveURL(/\/login/);
    await expect(this.submitButton).toBeVisible();
  }

  async assertFormIsEmpty(): Promise<void> {
    await expect(this.emailInput).toHaveValue('');
    await expect(this.passwordInput).toHaveValue('');
  }
}
