import { type Page, type Locator, expect } from '@playwright/test';
import type { ProjectStatus } from '../utils/test-data';

/**
 * DashboardPage - Main workspace after login.
 *
 * Business context: Central hub where users manage signing projects.
 * The project list is the core value proposition of the platform.
 */
export class DashboardPage {
  readonly page: Page;

  // Header actions
  readonly userMenuTrigger: Locator;
  readonly buyButton: Locator;
  readonly helpButton: Locator;

  // User dropdown items
  readonly preferencesMenuItem: Locator;
  readonly myAccountMenuItem: Locator;
  readonly myOrgMenuItem: Locator;
  readonly addressBookMenuItem: Locator;
  readonly logoutMenuItem: Locator;

  // Sidebar navigation
  readonly myProjectsNav: Locator;
  readonly orgProjectsNav: Locator;
  readonly orgUsersNav: Locator;
  readonly templatesNav: Locator;
  readonly sharedDocsNav: Locator;
  readonly trashNav: Locator;

  // Project list actions
  readonly newProjectButton: Locator;
  readonly searchInput: Locator;
  readonly statusFilterDropdown: Locator;
  readonly refreshButton: Locator;

  // Page heading
  readonly pageHeading: Locator;

  constructor(page: Page) {
    this.page = page;

    this.userMenuTrigger = page.getByText('HAMZA MADAOUI');
    this.buyButton = page.getByRole('button', { name: /acheter|buy/i });
    this.helpButton = page.getByText(/aide|\?/i).first();

    this.preferencesMenuItem = page.getByText('Préférences');
    this.myAccountMenuItem = page.getByText('Mon compte');
    this.myOrgMenuItem = page.getByText('Mon organisation');
    this.addressBookMenuItem = page.getByText("Carnet d'adresses");
    this.logoutMenuItem = page.getByText('Me déconnecter');

    this.myProjectsNav = page.getByTitle('Mes projets');
    this.orgProjectsNav = page.getByTitle("Projets de l'organisation");
    this.orgUsersNav = page.getByTitle("Utilisateurs de l'organisation");
    this.templatesNav = page.getByTitle('Modèles');
    this.sharedDocsNav = page.getByTitle('Mes documents partagés');
    this.trashNav = page.getByTitle('Corbeille');

    this.newProjectButton = page.getByRole('button', { name: /nouveau projet/i });
    this.searchInput = page.getByRole('textbox', { name: /recherche|search/i });
    // The filter is a nice-select custom dropdown with class .workflow-filter
    this.statusFilterDropdown = page.locator('.nice-select.workflow-filter');
    this.refreshButton = page.getByRole('button', { name: /rafraîchir/i });

    this.pageHeading = page.getByRole('heading', { level: 1 });
  }

  async goto(): Promise<void> {
    await this.page.goto('/#/dashboard');
    await this.page.waitForLoadState('networkidle');
  }

  async openUserMenu(): Promise<void> {
    await this.userMenuTrigger.click();
  }

  async logout(): Promise<void> {
    await this.openUserMenu();
    await this.logoutMenuItem.click();
    await this.page.waitForURL(/\/login/, { timeout: 10_000 });
  }

  async filterProjectsByStatus(status: ProjectStatus): Promise<void> {
    // Click trigger to open the nice-select dropdown
    await this.statusFilterDropdown.click();
    // Click the option within the dropdown list
    await this.statusFilterDropdown.locator('.list li').filter({ hasText: status }).click();
  }

  async searchForProject(query: string): Promise<void> {
    await this.searchInput.fill(query);
    // Debounce delay - the search typically triggers after typing
    await this.page.waitForTimeout(500);
  }

  async clearSearch(): Promise<void> {
    await this.searchInput.clear();
    await this.page.waitForTimeout(300);
  }

  async navigateToTemplates(): Promise<void> {
    await this.templatesNav.click();
    await expect(this.pageHeading).toContainText(/modèles/i);
  }

  async navigateToOrgUsers(): Promise<void> {
    await this.orgUsersNav.click();
  }

  async getCurrentSectionHeading(): Promise<string> {
    return (await this.pageHeading.textContent()) ?? '';
  }

  async assertOnDashboard(): Promise<void> {
    // App uses /#/ or /#/dashboard for the main dashboard
    await expect(this.page).toHaveURL(/cloud\.consigno\.com\/#/);
    await expect(this.newProjectButton).toBeVisible();
  }
}
