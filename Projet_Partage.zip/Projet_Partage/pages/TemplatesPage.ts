import { type Page, type Locator, expect } from '@playwright/test';

/**
 * TemplatesPage - Reusable signing project templates.
 *
 * Business context: Power users pre-define signing workflows as templates
 * to avoid re-configuring the same project structure repeatedly.
 */
export class TemplatesPage {
  readonly page: Page;

  readonly heading: Locator;
  readonly newTemplateLink: Locator;
  readonly searchInput: Locator;
  readonly templateTable: Locator;
  readonly emptyStateMessage: Locator;

  // Table columns
  readonly nameColumn: Locator;
  readonly lastModifiedColumn: Locator;
  readonly modifiedByColumn: Locator;
  readonly actionsColumn: Locator;

  constructor(page: Page) {
    this.page = page;

    this.heading = page.getByRole('heading', { name: /modèles/i });
    this.newTemplateLink = page.getByRole('link', { name: /nouveau modèle/i });
    this.searchInput = page.getByRole('textbox', { name: /rechercher/i });
    this.templateTable = page.getByRole('table');
    this.emptyStateMessage = page.getByText(/aucun modèle/i);

    this.nameColumn = page.getByRole('columnheader', { name: /nom/i });
    this.lastModifiedColumn = page.getByRole('columnheader', { name: /dernière modification/i });
    this.modifiedByColumn = page.getByRole('columnheader', { name: /modifié par/i });
    this.actionsColumn = page.getByRole('columnheader', { name: /actions/i });
  }

  async assertPageLoaded(): Promise<void> {
    await expect(this.heading).toBeVisible();
    await expect(this.newTemplateLink).toBeVisible();
    await expect(this.searchInput).toBeVisible();
  }

  async assertTableColumnsPresent(): Promise<void> {
    await expect(this.nameColumn).toBeVisible();
    await expect(this.lastModifiedColumn).toBeVisible();
    await expect(this.modifiedByColumn).toBeVisible();
    await expect(this.actionsColumn).toBeVisible();
  }
}
