import { type Page, type Locator, expect } from '@playwright/test';

/**
 * UserAccountPage - User profile and security settings.
 *
 * Business context: Where users manage identity information and
 * 2-factor authentication (critical for a legally-binding e-signature platform).
 */
export class UserAccountPage {
  readonly page: Page;

  readonly heading: Locator;

  // Identity fields
  readonly firstNameInput: Locator;
  readonly lastNameInput: Locator;
  readonly emailInput: Locator;

  // Security
  readonly changePasswordSection: Locator;
  readonly twoFactorMethodDropdown: Locator;
  readonly phoneNumberInput: Locator;
  readonly countryCodeButton: Locator;

  // Navigation
  readonly backLink: Locator;

  constructor(page: Page) {
    this.page = page;

    this.heading = page.getByRole('heading', { name: /mon compte/i });
    this.firstNameInput = page.getByRole('textbox', { name: /prénom/i });
    this.lastNameInput = page.getByRole('textbox', { name: /^nom$/i });
    this.emailInput = page.getByRole('textbox', { name: /courriel/i });

    this.changePasswordSection = page.getByText(/changer le mot de passe/i);
    this.twoFactorMethodDropdown = page.getByText(/second facteur d'authentification/i);
    this.phoneNumberInput = page.getByRole('textbox', { name: /numéro de téléphone/i });
    this.countryCodeButton = page.getByRole('button', { name: /change country/i });

    this.backLink = page.getByRole('link', { name: /retour/i });
  }

  async goto(): Promise<void> {
    await this.page.goto('/#/user-account');
    await this.page.waitForLoadState('networkidle');
  }

  async assertProfileData(firstName: string, lastName: string, email: string): Promise<void> {
    await expect(this.firstNameInput).toHaveValue(firstName);
    await expect(this.lastNameInput).toHaveValue(lastName);
    await expect(this.emailInput).toHaveValue(email);
  }

  async assertPageLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/#\/user-account/);
    await expect(this.heading).toBeVisible();
    await expect(this.firstNameInput).toBeVisible();
  }
}
