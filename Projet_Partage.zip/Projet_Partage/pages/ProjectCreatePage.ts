import { type Page, type Locator, expect } from '@playwright/test';

/**
 * ProjectCreatePage - Signature project creation wizard.
 *
 * Business context: Core workflow - creating a signing project with
 * documents, signatories, and expiration rules. This is where the
 * business value is created.
 */
export class ProjectCreatePage {
  readonly page: Page;

  // Form inputs
  readonly projectNameInput: Locator;
  readonly expirationDateInput: Locator;

  // Toolbar buttons
  readonly addSignatoryButton: Locator;
  readonly addTextFieldButton: Locator;
  readonly optionsButton: Locator;

  // Signing order section
  readonly signingOrderSection: Locator;

  // File upload
  readonly fileUploadArea: Locator;
  readonly selectFilesButton: Locator;

  // Action buttons
  readonly cancelButton: Locator;
  readonly saveButton: Locator;
  readonly launchButton: Locator;

  // Message to signatories
  readonly addMessageButton: Locator;

  // Zone counter
  readonly zoneCounter: Locator;

  constructor(page: Page) {
    this.page = page;

    this.projectNameInput = page.getByRole('textbox', { name: /nom du projet/i });
    this.expirationDateInput = page.getByRole('textbox', { name: /jj\/mm\/aaaa/i });

    // Use :has-text() CSS pseudo-class for reliable text-based matching
    this.addSignatoryButton = page.locator('button:has-text("Signataires")').first();
    this.addTextFieldButton = page.locator('button:has-text("Champ de texte")').first();
    // Options button shows as "..." icon - match by accessible name (title/aria-label)
    this.optionsButton = page.getByRole('button', { name: /options/i }).first();

    this.signingOrderSection = page.getByText(/ordre de signature/i);

    this.fileUploadArea = page.getByText(/glisser-déposer/i);
    this.selectFilesButton = page.getByRole('button', { name: /sélectionner les fichiers/i });

    // Use specific CSS classes to avoid matching hidden datepicker "Annuler" buttons
    this.cancelButton = page.locator('button.btn-default-cancel');
    this.saveButton = page.locator('button').filter({ hasText: 'Sauvegarder' });
    this.launchButton = page.locator('button').filter({ hasText: 'Lancer' });

    this.addMessageButton = page.getByRole('button', {
      name: /ajouter un message à destination/i,
    });

    this.zoneCounter = page.getByText(/nombre de zone définie/i);
  }

  async goto(): Promise<void> {
    await this.page.goto('/#/workflow/create');
    await this.page.waitForLoadState('networkidle');
  }

  async fillProjectName(name: string): Promise<void> {
    await this.projectNameInput.fill(name);
  }

  async setExpirationDate(date: string): Promise<void> {
    await this.expirationDateInput.fill(date);
  }

  async cancel(): Promise<void> {
    await this.cancelButton.click();
    // Cancel redirects to /#/ (root) which renders the dashboard
    await this.page.waitForURL(/cloud\.consigno\.com\/#/, { timeout: 10_000 });
  }

  async getZoneCount(): Promise<number> {
    const text = await this.zoneCounter.textContent();
    const match = text?.match(/(\d+)/);
    return match ? parseInt(match[1], 10) : 0;
  }

  async assertPageLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/#\/workflow\/create/);
    await expect(this.page.getByRole('heading', { name: /créer un projet/i })).toBeVisible();
    await expect(this.projectNameInput).toBeVisible();
    await expect(this.selectFilesButton).toBeVisible();
  }

  async assertDefaultExpirationDateIsSet(): Promise<void> {
    const value = await this.expirationDateInput.inputValue();
    expect(value).toMatch(/\d{2}\/\d{2}\/\d{4}/);
  }
}
